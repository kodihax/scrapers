# a4kScrapers

Provider for [Seren](https://github.com/nixgates/plugin.video.seren)  
Latest version: [bit.ly/a4kScrapers](https://bit.ly/a4kScrapers)

**Status**  
AppVeyor:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![Build status](https://ci.appveyor.com/api/projects/status/kdm6f2xk4s36ytpo?svg=true)](https://ci.appveyor.com/project/newt-sc/a4kScrapers)  
Codefresh:&nbsp;&nbsp;&nbsp;[![Codefresh build status]( https://g.codefresh.io/api/badges/pipeline/newt-sc/a4k-openproject%2Fa4kScrapers%2Fa4kScrapers?branch=master&key=eyJhbGciOiJIUzI1NiJ9.NWM3YWFlOGFhNmQ2MDExNTdmZmM1N2M2.jq7DcvOImjNXgcA-hCGmqo7_TPqgyOe-MyfvLw2DazA&type=cf-1)]( https://g.codefresh.io/pipelines/a4kScrapers/builds?repoOwner=a4k-openproject&repoName=a4kScrapers&serviceName=a4k-openproject%2Fa4kScrapers&filter=trigger:build~Build;branch:master;pipeline:5c883aef34520407784410e2~a4kScrapers)  
CircleCI:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![CircleCI](https://circleci.com/gh/a4k-openproject/a4kScrapers.svg?style=svg)](https://circleci.com/gh/a4k-openproject/a4kScrapers)  
Semaphore:&nbsp;&nbsp;[![Build Status](https://semaphoreci.com/api/v1/newt-sc/a4kscrapers/branches/master/shields_badge.svg)](https://semaphoreci.com/newt-sc/a4kscrapers)  
Shippable:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![Run Status](https://api.shippable.com/projects/5c7ab3b6867d9e0700f6fa64/badge?branch=master)](https://app.shippable.com/github/a4k-openproject/a4kScrapers/dashboard)  
Travis:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![Build Status](https://travis-ci.com/a4k-openproject/a4kScrapers.svg?branch=master)](https://travis-ci.com/a4k-openproject/a4kScrapers)  
Wercker:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![wercker status](https://app.wercker.com/status/3edd14e027f559dac94fc344cfb64733/s/master "wercker status")](https://app.wercker.com/project/byKey/3edd14e027f559dac94fc344cfb64733)  

Codeship*:&nbsp;&nbsp;&nbsp;&nbsp;[![Codeship Status](https://app.codeship.com/projects/a9879000-09ea-0137-e503-4277cc15dde1/status?branch=master)](https://app.codeship.com/projects/326157)  

\* - Do not run daily
